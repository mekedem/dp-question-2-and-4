package myesq.com.dp_project.Model;

/**
 * Created by Henkok on 2/1/2019.
 */

public class Product {
    private String name;
    private int numberOfShipped;

    public Product(String name, int numberOfShipped) {
        this.name = name;
        this.numberOfShipped = numberOfShipped;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfShipped() {
        return numberOfShipped;
    }

    public void setNumberOfShipped(int numberOfShipped) {
        this.numberOfShipped = numberOfShipped;
    }
}
