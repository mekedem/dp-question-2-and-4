package myesq.com.dp_project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import myesq.com.dp_project.Model.Product;
import myesq.com.dp_project.Model.ProductListBridge;
import myesq.com.dp_project.Model.Store;

public class Question2Activity extends AppCompatActivity {

    Spinner displayType, sortBy;
    List<Product> products = new ArrayList<>();

    String[] displayTypes;
    String[] sortBys;

    ListView[] productViews;
    ProductListBridge[] bridges;

    int currentlyShowingList = 0;
    int currentSortby = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);

        displayType = findViewById(R.id.displayType);
        sortBy = findViewById(R.id.sortBy);
        productViews = new ListView[]{findViewById(R.id.customerView), findViewById(R.id.executiveView)};

        displayTypes = new String[]{"Customer", "Executive"};
        sortBys = new String[]{"none", "Alphabet"};

        displayType.setAdapter(
                new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, displayTypes)
        );

        displayType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (currentlyShowingList != position) {
                    currentlyShowingList = position;
                    selectView();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        sortBy.setAdapter(
                new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, sortBys)
        );

        sortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (currentSortby != position) {
                    currentSortby = position;
                    bridges[currentlyShowingList].sort(position == 0 ? false : true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        initilizeStore();

        bridges = new ProductListBridge[] {
                new ProductListBridge(this, productViews[0], products, ProductListBridge.SIMPLE_LIST),
                new ProductListBridge(this, productViews[1], products, ProductListBridge.DETAILED_LIST)
        };

       selectView();

    }

    public void initilizeStore() {
        products.clear();
        for (int i = 0; i < 10; i++) {
            products.add(
                    new Product("Product " + i, i*i)
            );
        }
    }

    public void selectView() {
        productViews[currentlyShowingList].setVisibility(View.VISIBLE);
        productViews[(currentlyShowingList + 1) % 2].setVisibility(View.GONE);
        bridges[currentlyShowingList].sort(currentSortby == 0? false: true);
    }
}
