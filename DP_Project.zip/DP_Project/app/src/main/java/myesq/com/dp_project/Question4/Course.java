package myesq.com.dp_project.Question4;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

abstract class Course {
    private String name;
    protected List<Note> notes = new ArrayList<>();
    public int courseIndex = 0;

    public Course(String name) {
        this.name = name;
        prepareNotes();
    }

    public abstract void prepareNotes();

    public Note getNextNote() {
        return notes.get(courseIndex);
    }
}
