package myesq.com.dp_project.Model;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

public class SimpleProductList extends ProductList{

    public SimpleProductList(Context ctx, ListView listView, List<Product> products) {
        super(ctx, listView, products);
    }

    @Override
    protected List<String> getProductsNames() {
        List<String> names = new ArrayList<String>();
        for (Product product: products){
            names.add(product.getName());
        }
        return names;
    }


}
