package myesq.com.dp_project.Model;

import android.content.Context;
import android.widget.ListView;

import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

public class ProductListBridge {
    public static final int SIMPLE_LIST = 0, DETAILED_LIST = 1;
    ProductList productList = null;

    public ProductListBridge(Context ctx, ListView listView, List<Product> products, int listType) {
        if (listType == SIMPLE_LIST){
            productList = new SimpleProductList(ctx, listView, products);
        }
        else if (listType == DETAILED_LIST){
            productList = new DetailedProductList(ctx, listView, products);
        }
    }

    public void sort(boolean sort){
        productList.sortProducts(sort);
    }
}
