package myesq.com.dp_project.Question4;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Note {
    private List<String> letters;
    private String voice;
    private boolean isCompleted;


    public Note(List<String > letters, String voice, boolean isCompleted) {
        this.letters = letters;
        this.voice = voice;
        this.isCompleted = isCompleted;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public List<String> getLetters() {
        return letters;
    }

    public String getVoice(int index) {
        if (letters.size() == 4) {
            return Util.getVoice(letters.get(index), -1);
        }
        return Util.getVoice(voice, index);
    }

    public List<Quiz> getQuizzes() {
        int[] quizeOrders = shuffledNumbers(this.letters.size(), -1);
        List<Quiz> quizes = new ArrayList<>();
        for (int i = 0; i < this.letters.size(); i++) {
            quizes.add(prepareQuize(quizeOrders[i]));
        }
        return quizes;
    }

    private int[] shuffledNumbers(int length, int noInclude) {
        int[] array;
        if (noInclude == -1) array = new int[length];
        else array = new int[length - 1];
        Random rgen = new Random();  // Random number generator

        for (int i = 0, j = 0; i < array.length; i++, j++) {
            if (j == noInclude)
                array[i] = ++j ;
            else
                array[i] = j;
        }

        for (int i=0; i<array.length; i++) {
            int randomPosition = rgen.nextInt(array.length);
            int temp = array[i];
            array[i] = array[randomPosition];
            array[randomPosition] = temp;
        }

        return array;
    }

    private Quiz prepareQuize(int shouldInclude) {
        int[] array = shuffledNumbers(letters.size(), shouldInclude);
        Random rgen = new Random();
        int answerIndex = rgen.nextInt(3);

        List<String> choices = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            System.out.println(array[i]);
            choices.add(letters.get(array[i]));
        }
        choices.add(answerIndex, letters.get(shouldInclude));

        String voicee = letters.size() <= 4? letters.get(shouldInclude): voice;
        int voiceeIndex = letters.size() <= 4? -1: shouldInclude;


        Quiz quiz = new Quiz(letters.get(shouldInclude), choices, answerIndex, voicee, voiceeIndex);
        return quiz;
    }


}
