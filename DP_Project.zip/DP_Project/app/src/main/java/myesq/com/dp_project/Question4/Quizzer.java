package myesq.com.dp_project.Question4;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

import myesq.com.dp_project.R;

/**
 * Created by Henkok on 2/2/2019.
 */

public class Quizzer extends Fragment implements View.OnClickListener {
    private static Quizzer instance = null;
    private TextView answerDesc, quizeIndex;
    private RadioGroup choices;
    private RadioButton one, two, three, four;
    private List<Quiz> quizes;
    private ImageView answerCorrectness;
    private Button checkAnswer;
    private ImageButton questionBtn;
    private LinearLayout answerWrapper;
    private DisplayCompeleted displayCompeleted;
    private int index = 0;
    TextToSpeech t1;


    private boolean showContinue = false;


    public Quizzer(){
        // do something
    }

    public static Quizzer getInstance() {
        if (instance == null)
            instance = new Quizzer();
        return instance;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        t1 = new TextToSpeech(getActivity().getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.quize, container, false);
        questionBtn = view.findViewById(R.id.questionBtn);

        answerDesc = view.findViewById(R.id.answerDesc);
        quizeIndex = view.findViewById(R.id.quizeIndex);
        choices = view.findViewById(R.id.choices);

        one = view.findViewById(R.id.choiceOne);
        two = view.findViewById(R.id.choiceTwo);
        three = view.findViewById(R.id.choiceThree);
        four = view.findViewById(R.id.choiceFour);

        answerCorrectness = view.findViewById(R.id.answerStatus);
        checkAnswer = view.findViewById(R.id.checkAnswer);
        answerWrapper = view.findViewById(R.id.answerWrapper);

        checkAnswer.setOnClickListener(this);
        questionBtn.setOnClickListener(this);

        showQuize();
        return view;
    }

    public void showQuize(){
        Quiz quiz = quizes.get(index);
        one.setText(quiz.getChoices().get(0));
        two.setText(quiz.getChoices().get(1));
        three.setText(quiz.getChoices().get(2));
        four.setText(quiz.getChoices().get(3));
        quizeIndex.setText((index+1) + "/" + quizes.size());
        choices.clearCheck();
        answerWrapper.setVisibility(View.GONE);

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.checkAnswer){
            if (showContinue) {
                if (++index >= quizes.size()) {
                    displayCompeleted.onCompleted(false);
                }
                else {
                    showQuize();
                    showContinue = false;
                }
            }
            else {
                Quiz quize = quizes.get(index);
                boolean isCorrect = getChosenAnswerIndex() == quize.getAnswerIndex();
                answerCorrectness.setImageResource(isCorrect?R.drawable.ic_check_black_24dp: R.drawable.ic_close_black_24dp);
                answerDesc.setText(isCorrect?
                        "Your answer is correct!":
                        "The correct answer is " + quize.getChoices().get(quize.getAnswerIndex())
                );
                answerWrapper.setVisibility(View.VISIBLE);
                checkAnswer.setText("Continue");
                showContinue = true;
            }

        }
        else if (id == R.id.questionBtn) {
            Quiz quiz = quizes.get(index);
            t1.speak(quiz.getVoice(quizes.size() <= 4, index), TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    public void setData(List<Quiz> quizes, DisplayCompeleted displayCompeleted) {
        this.quizes = quizes;
        this.displayCompeleted = displayCompeleted;
    }

    public int getChosenAnswerIndex() {
        switch (choices.getCheckedRadioButtonId()) {
            case R.id.choiceOne:
                return 0;
            case R.id.choiceTwo:
                return 1;
            case R.id.choiceThree:
                return 2;
            case R.id.choiceFour:
                return 3;
        }
        return -1;
    }


}
