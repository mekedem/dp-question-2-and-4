package myesq.com.dp_project.Question4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Amharic {

    private String alpha = "ሀ ሁ	 ሂ ሃ ሄ ህ ሆ\n" +
            "ለ  ሉ ሊ ላ ሌ ል ሎ\n" +
            "ሐ ሑ ሒ ሓ ሔ ሕ ሖ\n" +
            "መ ሙ ሚ ማ ሜ ም ሞ\n" +
            "ሠ ሡ ሢ ሣ ሤ ሥ ሦ\n" +
            "ረ ሩ ሪ ራ ሬ ር ሮ\n" +
            "ሰ ሱ ሲ ሳ ሴ ስ ሶ\n" +
            "ሸ ሹ ሺ ሻ ሼ ሽ ሾ\n" +
            "ቀ ቁ ቂ ቃ ቄ ቅ ቆ\n" +
            "በ ቡ ቢ ባ ቤ ብ ቦ\n" +
            "ቨ ቩ ቪ ቫ ቬ ቭ ቮ\n" +
            "ተ ቱ ቲ ታ ቴ ት ቶ\n" +
            "ቸ ቹ ቺ ቻ ቼ ች ቾ\n" +
            "ኀ ኁ ኂ ኃ ኄ ኅ ኆ\n" +
            "ነ ኑ ኒ ና ኔ ን ኖ\n" +
            "ኘ ኙ ኚ ኛ ኜ ኝ ኞ\n" +
            "አ ኡ ኢ ኣ ኤ እ ኦ\n" +
            "ከ ኩ ኪ ካ ኬ ክ ኮ\n" +
            "ኸ ኹ ኺ ኻ ኼ ኽ ኾ\n" +
            "ወ ዉ ዊ ዋ ዌ ው ዎ\n" +
            "ዐ ዑ ዒ ዓ ዔ ዕ ዖ\n" +
            "ዘ ዙ ዚ ዛ ዜ ዝ ዞ\n" +
            "ዠ ዡ ዢ ዣ ዤ ዥ ዦ\n" +
            "የ ዩ ዪ ያ ዬ ይ ዮ\n" +
            "ደ ዱ ዲ ዳ ዴ ድ ዶ\n" +
            "ጀ ጁ ጂ ጃ ጄ ጅ ጆ\n" +
            "ገ ጉ ጊ ጋ ጌ ግ ጎ\n" +
            "ጠ ጡ ጢ ጣ ጤ ጥ ጦ\n" +
            "ጨ ጩ ጪ ጫ ጬ ጭ ጮ\n" +
            "ጰ ጱ ጲ ጳ ጴ ጵ ጶ\n" +
            "ጸ ጹ ጺ ጻ ጼ ጽ ጾ\n" +
            "ፀ ፁ ፂ ፃ ፄ ፅ ፆ\n" +
            "ፈ ፉ ፊ ፋ ፌ ፍ ፎ\n" +
            "ፐ ፑ ፒ ፓ ፔ ፕ ፖ";

    private List<String> voice_ = Arrays.asList(
            "h l h m s r s ʃ q β t ʧ χ n ɲ ʔ k x w ʢ z ʒ j d j g tʼ ʧʼ pʼ ʦʼ ƛʼ ɸ p".split(" "));

    private List<String> alphabet;

    public Amharic() {
        alphabet = new ArrayList<>();
        alphabet.addAll(Arrays.asList(alpha.split("\n")));
    }

//    public Quiz buildQuiz(String parentLetter) {/*
//        int letterIndex = voice_.indexOf(parentLetter);
//        String[] letterFamily = alphabet.get(letterIndex).split(" ");
//
//        Random random = new Random();
//        Set<Integer> choice_indices = new HashSet<>();
//
//        while (choice_indices.size() < 4) {
//            choice_indices.add(random.nextInt(7));
//        }
//
//        int answerIndex = (int) choice_indices.toArray()[random.nextInt(4)];
//        String question = Util.getVoice(parentLetter, answerIndex);
//        List<String> choices = new ArrayList<>();
//
//        for (Iterator i = choice_indices.iterator(); i.hasNext();) {
//            choices.add(letterFamily[(int) i.next()]);
//        }
//
//        return new Quiz(question, choices, answerIndex);
//    }
//
//    public Note getNote(int index) {
//        int round_index = index % 34;
//        List<String> letterFamily = Arrays.asList(alphabet.get(round_index).split(" "));
//        String voice = voice_.get(round_index);
//
//        return new Note(letterFamily, voice, false); */
//    }
}
