package myesq.com.dp_project.Question4;

import android.speech.tts.TextToSpeech;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Util {
    private static String[] vowels = {"e", "u", "i", "a", "eigh", "eh", "o"};

    public static String getVoice(String parentLetter, int index) {
        if (index == -1) return parentLetter;

        if (index >= 0 && index <=6) {
            return parentLetter + vowels[index];
        }

        return null;
    }


}
