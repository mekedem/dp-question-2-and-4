package myesq.com.dp_project.Question4;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

import myesq.com.dp_project.R;

/**
 * Created by Henkok on 2/6/2019.
 */

public class NoteDisplayer extends Fragment implements View.OnClickListener {
    private static int index;
    TextView note;
    ImageButton voiceBtn;
    Button nextBtn, prevBtn;

    Note currentNote;

    private boolean takeQuize = false;
    private static NoteDisplayer instance = null;
    private DisplayCompeleted displayCompeleted;
    TextToSpeech t1;

    public static NoteDisplayer getInstance() {
        if (instance == null)
            instance = new NoteDisplayer();
        return instance;
    }

    public NoteDisplayer(){

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        t1 = new TextToSpeech(getActivity().getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.note_displayer, container, false);
        note = view.findViewById(R.id.note);
        note.setText(currentNote.getLetters().get(index));

        voiceBtn = view.findViewById(R.id.voiceBtn);
        prevBtn = view.findViewById(R.id.prevBtn);
        nextBtn = view.findViewById(R.id.nextBtn);

        voiceBtn.setOnClickListener(this);
        prevBtn.setOnClickListener(this);
        nextBtn.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();

        if (id == R.id.nextBtn){
            //
            if (takeQuize) {
                displayCompeleted.onCompleted(true);
            }
            else {
                index++;
                note.setText(currentNote.getLetters().get(index));
                prevBtn.setEnabled(true);
                if (index == currentNote.getLetters().size() - 1) {
                    nextBtn.setText("Take Quize");
                    takeQuize = true;
                }
            }
        }
        else if( id == R.id.prevBtn) {
            takeQuize = false;
            nextBtn.setText("Next");
            if (index == 0) {
                prevBtn.setEnabled(false);
            }
            else {
                index--;
                note.setText(currentNote.getLetters().get(index));
                nextBtn.setEnabled(true);
            }
        }
        else if (id == R.id.voiceBtn){
            t1.speak(currentNote.getVoice(index), TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    public void setData(Note note, DisplayCompeleted displayCompeleted) {
        this.currentNote = note;
        this.displayCompeleted = displayCompeleted;
        index = 0;
        takeQuize = false;
    }



}
