package myesq.com.dp_project.Question4;

import java.util.List;

public class Quiz {

    private String question;
    private List<String> choices;
    private int answerIndex;
    private String voice;
    private int voiceIndex;

    public Quiz(String question, List<String> choices, int answerIndex, String voice, int voiceIndex) {
        this.question = question;
        this.choices = choices;
        this.answerIndex = answerIndex;
        this.voice = voice;
        this.voiceIndex = voiceIndex;
    }

    public String getQuestion() {
        return question;
    }

    public List<String> getChoices() {
        return choices;
    }

    public int getAnswerIndex() {
        return answerIndex;
    }

    @Override
    public String toString() {
        String melis = "Question: " + question + "\n";
        for (int i = 0; i < 4; i++) {
            melis += " \t" + choices.get(i) + " \n";
        }
        return melis;
    }

    public String getVoice(boolean isEnglish, int index) {
        if (isEnglish) {
            return Util.getVoice(question, -1);
        }
        return Util.getVoice(voice, voiceIndex);
    }
}