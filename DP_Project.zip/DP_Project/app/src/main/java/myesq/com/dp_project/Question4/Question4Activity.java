package myesq.com.dp_project.Question4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import myesq.com.dp_project.R;

public class Question4Activity extends AppCompatActivity implements DisplayCompeleted{

    public static final String CHOOSEN_COURSE = "fjsadkfjasdlkjglkasdjglksd";
    NoteDisplayer noteDisplayer;
    Quizzer quizzer;

    Course course;
    Note currentNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // there should be an intent here
        Intent intent = getIntent();
        int courseIndex = intent.getIntExtra(CHOOSEN_COURSE, 0);

        CourseFactory courseFactory = new CourseFactory();
        course = courseFactory.getCourse(courseIndex);

        noteDisplayer = NoteDisplayer.getInstance();
        currentNote = course.getNextNote();
        noteDisplayer.setData(currentNote, this);

        quizzer = Quizzer.getInstance();
        quizzer.setData(currentNote.getQuizzes(), this);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.courseContent, noteDisplayer).commit();
    }

    @Override
    public void onCompleted(boolean isNote) {
        if (isNote) {
            quizzer.setData(currentNote.getQuizzes(), this);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.courseContent, quizzer).commit();
            Toast.makeText(this, "Taking Quize", Toast.LENGTH_SHORT).show();
        }
        else {
            course.courseIndex++;
            currentNote = course.getNextNote();
            noteDisplayer.setData(currentNote, this);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.courseContent, noteDisplayer).commit();
        }
    }

}
