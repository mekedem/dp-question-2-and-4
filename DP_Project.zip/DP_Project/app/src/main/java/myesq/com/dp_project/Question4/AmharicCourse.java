package myesq.com.dp_project.Question4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

public class AmharicCourse extends Course {

    public AmharicCourse(String name) {
        super(name);
    }

    @Override
    public void prepareNotes() {
        String alpha = "ሀ ሁ	 ሂ ሃ ሄ ህ ሆ\n" +
                "ለ ሉ ሊ ላ ሌ ል ሎ\n" +
                "ሐ ሑ ሒ ሓ ሔ ሕ ሖ\n" +
                "መ ሙ ሚ ማ ሜ ም ሞ\n" +
                "ሠ ሡ ሢ ሣ ሤ ሥ ሦ\n" +
                "ረ ሩ ሪ ራ ሬ ር ሮ\n" +
                "ሰ ሱ ሲ ሳ ሴ ስ ሶ\n" +
                "ሸ ሹ ሺ ሻ ሼ ሽ ሾ\n" +
                "ቀ ቁ ቂ ቃ ቄ ቅ ቆ\n" +
                "በ ቡ ቢ ባ ቤ ብ ቦ\n" +
                "ተ ቱ ቲ ታ ቴ ት ቶ\n" +
                "ቸ ቹ ቺ ቻ ቼ ች ቾ\n" +
                "ኀ ኁ ኂ ኃ ኄ ኅ ኆ\n" +
                "ነ ኑ ኒ ና ኔ ን ኖ\n" +
                "ኘ ኙ ኚ ኛ ኜ ኝ ኞ\n" +
                "አ ኡ ኢ ኣ ኤ እ ኦ\n" +
                "ከ ኩ ኪ ካ ኬ ክ ኮ\n" +
                "ኸ ኹ ኺ ኻ ኼ ኽ ኾ\n" +
                "ወ ዉ ዊ ዋ ዌ ው ዎ\n" +
                "ዐ ዑ ዒ ዓ ዔ ዕ ዖ\n" +
                "ዘ ዙ ዚ ዛ ዜ ዝ ዞ\n" +
                "ዠ ዡ ዢ ዣ ዤ ዥ ዦ\n" +
                "የ ዩ ዪ ያ ዬ ይ ዮ\n" +
                "ደ ዱ ዲ ዳ ዴ ድ ዶ\n" +
                "ጀ ጁ ጂ ጃ ጄ ጅ ጆ\n" +
                "ገ ጉ ጊ ጋ ጌ ግ ጎ\n" +
                "ጠ ጡ ጢ ጣ ጤ ጥ ጦ\n" +
                "ጨ ጩ ጪ ጫ ጬ ጭ ጮ\n" +
                "ጰ ጱ ጲ ጳ ጴ ጵ ጶ\n" +
                "ጸ ጹ ጺ ጻ ጼ ጽ ጾ\n" +
                "ፀ ፁ ፂ ፃ ፄ ፅ ፆ\n" +
                "ፈ ፉ ፊ ፋ ፌ ፍ ፎ\n" +
                "ፐ ፑ ፒ ፓ ፔ ፕ ፖ";

        List<String> voices = Arrays.asList(
                "h l h m s r s ʃ q β t ʧ χ n ɲ ʔ k x w ʢ z ʒ j d j g tʼ ʧʼ pʼ ʦʼ ƛʼ ɸ p".split(" "));

        String[] alphas = alpha.split("\n");
        int size = alphas.length;
        for (int i = 0; i < size; i++) {
            String subAlpha = alphas[i];
            notes.add(
                    new Note(
                            Arrays.asList(subAlpha.split(" ")),
                            voices.get(i),
                            false
                    )
            );
        }
    }


}
