package myesq.com.dp_project.Question4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import myesq.com.dp_project.R;

public class CourseChooser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_chooser);
    }

    public void onCourseChosen(View view) {
        int id = view.getId();
        Intent intent = new Intent(this, Question4Activity.class);
        if (id == R.id.amharic) {
            intent.putExtra(Question4Activity.CHOOSEN_COURSE, CourseFactory.AMHARIC);
        }
        else if (id == R.id.english) {
            intent.putExtra(Question4Activity.CHOOSEN_COURSE, CourseFactory.ENGLISH);

        }
        startActivity(intent);
    }
}
