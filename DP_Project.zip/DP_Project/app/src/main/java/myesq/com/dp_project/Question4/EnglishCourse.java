package myesq.com.dp_project.Question4;

import android.util.Log;

import java.util.Arrays;
import java.util.List;

/**
 * Created by Henkok on 2/6/2019.
 */

public class EnglishCourse extends Course {
    public EnglishCourse(String name) {
        super(name);
    }

    @Override
    public void prepareNotes() {
        String[] alphas = {
                "A", "B", "C", "D", "E", "F", "G", "H",
                "I", "J", "K", "L", "M", "N", "O", "P",
                "Q", "R", "S", "T", "U", "V", "W", "X",
                "Y", "Z"
        };

        List<String> alphasList = Arrays.asList(alphas);
        for (int index = 0; index < 27; index += 4) {
            List<String> sublist = alphasList.subList(index, index + (index == 24? 2: 4));
            notes.add(
                    new Note(
                            sublist,
                            sublist.get(0),
                            false
                    )
            );
        }
    }
}
