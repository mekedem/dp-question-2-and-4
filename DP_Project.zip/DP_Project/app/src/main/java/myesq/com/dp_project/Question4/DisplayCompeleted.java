package myesq.com.dp_project.Question4;

/**
 * Created by Henkok on 2/6/2019.
 */

public interface DisplayCompeleted {
    public void onCompleted(boolean isNote);
}
