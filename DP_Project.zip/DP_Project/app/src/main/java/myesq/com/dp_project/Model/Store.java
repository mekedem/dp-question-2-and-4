package myesq.com.dp_project.Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Henkok on 2/1/2019.
 */


public class Store {
    private String name = "Mukera store";
    private String address = "yehone bota";
    private List<Product> products = new ArrayList<>();
    private static Store instance = null;

    private Store(){}

    public static Store getInstance(){
        if (instance == null)
            instance = new Store();
        return instance;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public List<Product> getProducts() {
        return products;
    }

    public List<String> getProductsNames() {
        List<String> names = new ArrayList<String>();
        for (Product product: products){
            names.add(product.getName());
        }
        return names;
    }

    public List<String> getProductsNamesWithShipped() {
        List<String> names = new ArrayList<String>();
        for (Product product: products){
            names.add(product.getNumberOfShipped() + "          " + product.getName());
        }
        return names;
    }}
