package myesq.com.dp_project.Model;

import android.content.Context;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

public class DetailedProductList extends ProductList {


    public DetailedProductList(Context ctx, ListView listView, List<Product> products) {
        super(ctx, listView, products);
    }

    @Override
    protected List<String> getProductsNames() {
        List<String> names = new ArrayList<String>();
        for (Product product: products){
            names.add(product.getNumberOfShipped() + "          " + product.getName());
        }
        return names;
    }
}
