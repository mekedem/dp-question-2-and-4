package myesq.com.dp_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import myesq.com.dp_project.Question4.CourseChooser;
import myesq.com.dp_project.Question4.Question4Activity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void handleClick(View view) {
        int id = view.getId();
        Intent intent = null;

        switch (id) {
            case R.id.q1:
                intent = new Intent(this, null);
                break;
            case R.id.q2:
                intent = new Intent(this, Question2Activity.class);
                break;
            case R.id.q3:
                intent = new Intent(this, null);
                break;
            case R.id.q4:
                intent = new Intent(this, CourseChooser.class);
                break;
        }

        startActivity(intent);
    }
}
