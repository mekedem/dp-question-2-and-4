package myesq.com.dp_project.Question4;

/**
 * Created by Henkok on 2/2/2019.
 */

public class CourseFactory {
    public static final int AMHARIC = 0;
    public static final int ENGLISH = 1;

    public Course getCourse(int course) {
        switch (course) {
            case AMHARIC:
                return new AmharicCourse("Amharic");
            case ENGLISH:
                return new EnglishCourse("English");
        }

        return null;
    }
}
