package myesq.com.dp_project.Model;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Henkok on 2/2/2019.
 */

public abstract class ProductList {
    private ListView listView;
    protected List<Product> products;
    protected boolean sort = false;
    private ArrayAdapter adapter;
    private Context ctx;

    public ProductList(Context ctx, ListView listView, List<Product> products) {
        this.listView = listView;
        this.ctx = ctx;
        this.products = products;

        adapter = new ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, getProductsNames());
        this.listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void sortProducts(boolean sort) {
        if (this.sort != sort){
            this.sort = sort;
            Toast.makeText(ctx, "Sorting " + sort, Toast.LENGTH_SHORT).show();
        }
        // do the sorting
    }


    protected abstract List<String> getProductsNames();
}
